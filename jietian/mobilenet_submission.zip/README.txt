DATA255 MobileNetV3-Small results

Three runs: 100%, 50%, 25%; 10 epochs each; ImageNet pretrained.
Original Nathan patched train.py and shared CSVs, seed 2026, lr 0.0001, weight_decay 0.0001, batch_size 32.
Validation/test splits are fixed. Training subsets contain 7263 / 3632 / 1828 images.
The <run>_best.pt files contain model.state_dict() only.
Prediction CSVs contain Image Index followed by the 14 labels in the original order, holding sigmoid probabilities.
Best checkpoints were selected by validation macro AUC.
All AUCs were independently recomputed from prediction CSVs; weights, row order, label order, and checkpoint consistency passed validation.

Images used a lossless cache of RGB conversion and 224x224 bilinear resize. All cached pixel hashes and 16 original-image comparisons against torchvision Resize passed. Random training flip and ImageNet normalization remain in the original trainer.
All 30 epoch checkpoints and original legacy output filenames are retained in the full mobilenet_results.zip archive outside this compact submission.
